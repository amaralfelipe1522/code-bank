# Imersão Fullcycle 3 - Codebank
![Imersão Full Stack && Full Cycle](https://events-fullcycle.s3.amazonaws.com/events-fullcycle/static/site/img/grupo_4417.png)

Participe gratuitamente: https://imersao.fullcycle.com.br/

## Sobre o repositório
Esse repositório contém todo código utilizado durante as aulas para referência.

Faça seu fork e também nos dê uma estrelinha para nos ajudar a divulgar o projeto.

As instruções de instalações estão no README.md de cada projeto.

## Ordem recomendada de execução

* Apache Kafka
* Codebank (Golang)
* Back-end e front-end da loja (Nest.js e Next.js)
* Back-end e front-end das faturas (Nest.js e Next.js)
